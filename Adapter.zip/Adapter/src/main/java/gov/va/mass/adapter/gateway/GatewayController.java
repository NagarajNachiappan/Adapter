package gov.va.mass.adapter.gateway;

/**
 * Created by n_nac on 8/23/2017.
 */



import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RequestMapping("/Adapter/Gateway/**")

@RestController

public class GatewayController {


    @RequestMapping( method= RequestMethod.POST, produces = "application/hl7-v2+er7")
    public String method3(){
        System.out.println("In method 3");
        return "method3";
    }

}